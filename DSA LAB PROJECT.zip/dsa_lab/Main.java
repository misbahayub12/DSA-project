import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Class representing a weather record
class WeatherRecord {
    private String location;
    private String date;
    private double temperature;

    // Constructor for WeatherRecord
    public WeatherRecord(String location, String date, double temperature) {
        this.location = location;
        this.date = date;
        this.temperature = temperature;
    }

    // Getter methods for WeatherRecord
    public String getLocation() {
        return location;
    }

    public String getDate() {
        return date;
    }

    public double getTemperature() {
        return temperature;
    }
}

// AdminCredentials class to store admin credentials
class AdminCredentials {
    private String username;
    private String password;

    // Constructor for AdminCredentials
    public AdminCredentials(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter methods for AdminCredentials
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

// Editor class (can be extended in the future for more admin functionalities)
class Editor {
}

// CustomLinkedList implementation for managing weather updates (as a stack)
class CustomLinkedList<T> {
    private static class Node<T> {
        private T data;
        private Node<T> next;

        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node<T> head;

    public void push(T data) {
        Node<T> newNode = new Node<T>(data);
        newNode.next = head;
        head = newNode;
    }

    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        T data = head.data;
        head = head.next;
        return data;
    }

    public boolean isEmpty() {
        return head == null;
    }
}

// CustomHashMap implementation for storing weather records by location and date
class CustomHashMap<K, V> {
    public static final int INITIAL_CAPACITY = 10;
    private List<Entry<K, V>> entries;

    public CustomHashMap() {
        this.entries = new ArrayList<Entry<K, V>>(INITIAL_CAPACITY);
        for (int i = 0; i < INITIAL_CAPACITY; i++) {
            entries.add(null);
        }
    }

    public void put(K key, V value) {
        int index = getIndex(key);
        Entry<K, V> entry = entries.get(index);

        if (entry == null) {
            entries.set(index, new Entry<K, V>(key, value));
        } else {
            while (entry.next != null) {
                if (entry.key.equals(key)) {
                    entry.value = value;
                    return;
                }
                entry = entry.next;
            }
            entry.next = new Entry<K, V>(key, value);
        }
    }

    public V get(K key) {
        int index = getIndex(key);
        Entry<K, V> entry = entries.get(index);

        while (entry != null) {
            if (entry.key.equals(key)) {
                return entry.value;
            }
            entry = entry.next;
        }
        return null;
    }

    private int getIndex(K key) {
        return Math.abs(key.hashCode()) % INITIAL_CAPACITY;
    }

    private static class Entry<K, V> {
        private final K key;
        private V value;
        private Entry<K, V> next;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }
    }
}

// WeatherMonitoringSystem to manage weather records and user/admin actions
class WeatherMonitoringSystem {
    private List<WeatherRecord> weatherRecords;
    private CustomHashMap<String, List<WeatherRecord>> locationDataMap;
    private CustomHashMap<String, List<WeatherRecord>> dateDataMap;
    private List<AdminCredentials> adminCredentialsList;
    private CustomLinkedList<WeatherRecord> latestWeatherUpdates;

    public WeatherMonitoringSystem() {
        weatherRecords = new ArrayList<>();
        locationDataMap = new CustomHashMap<>();
        dateDataMap = new CustomHashMap<>();
        adminCredentialsList = new ArrayList<>();
        latestWeatherUpdates = new CustomLinkedList<>();

        // Sample admin users
        adminCredentialsList.add(new AdminCredentials("Misbah", "2380259"));
        adminCredentialsList.add(new AdminCredentials("Tania", "2380261"));
    }

    private Editor loginAsAdmin(String username, String password) {
        for (AdminCredentials credentials : adminCredentialsList) {
            if (credentials.getUsername().equals(username) && credentials.getPassword().equals(password)) {
                return new Editor();
            }
        }
        return null;
    }

    public void addWeatherRecord(WeatherRecord record) {
        weatherRecords.add(record);

        int index = getIndex(record.getLocation());
        List<WeatherRecord> locationRecords = locationDataMap.get(String.valueOf(index));
        if (locationRecords == null) {
            locationRecords = new ArrayList<>();
            locationDataMap.put(String.valueOf(index), locationRecords);
        }
        locationRecords.add(record);

        index = getIndex(record.getDate());
        List<WeatherRecord> dateRecords = dateDataMap.get(String.valueOf(index));
        if (dateRecords == null) {
            dateRecords = new ArrayList<>();
            dateDataMap.put(String.valueOf(index), dateRecords);
        }
        dateRecords.add(record);

        latestWeatherUpdates.push(record);
    }

    public void determineWeatherByLocation(String location) {
        int index = getIndex(location);
        List<WeatherRecord> records = locationDataMap.get(String.valueOf(index));
        if (records != null) {
            System.out.println("\nWeather Information for Location: " + location);
            for (WeatherRecord record : records) {
                System.out.println("Date: " + record.getDate() + ", Temperature: " + record.getTemperature());
            }
        } else {
            System.out.println("No weather records found for this location.");
        }
    }

    public void determineWeatherByDate(String date) {
        int index = getIndex(date);
        List<WeatherRecord> records = dateDataMap.get(String.valueOf(index));
        if (records != null) {
            System.out.println("\nWeather Information for Date: " + date);
            for (WeatherRecord record : records) {
                System.out.println("Location: " + record.getLocation() + ", Temperature: " + record.getTemperature());
            }
        } else {
            System.out.println("No weather information available for the specified date.");
        }
    }

    public void displayLatestWeatherUpdates(int count) {
        System.out.println("\nLatest Weather Updates:");
        for (int i = 0; i < count; i++) {
            if (!latestWeatherUpdates.isEmpty()) {
                WeatherRecord record = latestWeatherUpdates.pop();
                System.out.println("Location: " + record.getLocation() + ", Date: " + record.getDate() + ", Temperature: " + record.getTemperature());
            } else {
                System.out.println("No more updates available.");
            }
        }
    }

    public void addWeatherRecordByAdmin() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Admin Username: ");
        String adminUsername = scanner.next();

        System.out.print("Enter Admin Password: ");
        String adminPassword = scanner.next();

        Editor currentEditor = loginAsAdmin(adminUsername, adminPassword);

        if (currentEditor != null) {
            System.out.print("Enter Location: ");
            String location = scanner.next();

            System.out.print("Enter Date (YYYY-MM-DD): ");
            String date = scanner.next();

            System.out.print("Enter Temperature: ");
            double temperature = scanner.nextDouble();

            WeatherRecord newRecord = new WeatherRecord(location, date, temperature);
            addWeatherRecord(newRecord);

            System.out.println("Weather record added successfully!");
        } else {
            System.out.println("Invalid credentials. Weather record not added.");
        }
    }

    private int getIndex(String key) {
        return Math.abs(key.hashCode()) % CustomHashMap.INITIAL_CAPACITY;
    }
}

// Main class to run the system
public class Main {
    public static void main(String[] args) {
        WeatherMonitoringSystem weatherSystem = new WeatherMonitoringSystem();
        Scanner scanner = new Scanner(System.in);

        // Adding some sample records
        weatherSystem.addWeatherRecord(new WeatherRecord("Karachi", "2024-12-6", 25.5));
        weatherSystem.addWeatherRecord(new WeatherRecord("Lahore", "2024-12-6", 26.0));
        weatherSystem.addWeatherRecord(new WeatherRecord("Islamabad", "2024-12-6", 28.3));

        int roleChoice;
        do {
            System.out.println("\n******** Select Role ********");
            System.out.println("1. Admin");
            System.out.println("2. User");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            roleChoice = scanner.nextInt();

            if (roleChoice == 1) {
                weatherSystem.addWeatherRecordByAdmin();
            } else if (roleChoice == 2) {
                int userChoice;
                do {
                    System.out.println("\n******** User Options ********");
                    System.out.println("1. Determine Weather by Location");
                    System.out.println("2. Determine Weather by Date");
                    System.out.println("3. Display Latest Weather Updates");
                    System.out.println("4. Exit");
                    System.out.print("Enter your choice: ");
                    userChoice = scanner.nextInt();

                    switch (userChoice) {
                        case 1:
                            System.out.print("Enter Location: ");
                            String location = scanner.next();
                            weatherSystem.determineWeatherByLocation(location);
                            break;
                        case 2:
                            System.out.print("Enter Date (YYYY-MM-DD): ");
                            String date = scanner.next();
                            weatherSystem.determineWeatherByDate(date);
                            break;
                        case 3:
                            weatherSystem.displayLatestWeatherUpdates(1);
                            break;
                        case 4:
                            System.out.println("Exiting User Options.");
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } while (userChoice != 4);
            }
        } while (roleChoice != 3);

        System.out.println("Thank you for using our system. Goodbye!");
        scanner.close();
    }
}
